# TEK-INW — aktualna wersja

Aktywny folder: `2026-10-21_Wer 0.1` (od 21.10.2026). Aplikacja do inwentaryzacji budowlanej (iPad + laptop), wersja próbna 0.1.

- Publikacja na GitHub Pages i instalacja na iPadzie: `2026-10-21_Wer 0.1/WDROZENIE_GITHUB.md`
- Obsługa w terenie: `2026-10-21_Wer 0.1/INSTRUKCJA.md`
- Zmiany i stan testów: `2026-10-21_Wer 0.1/ZMIANY_WER_0.1.md`
- Na GitHub wgrywasz **tylko zawartość** `2026-10-21_Wer 0.1/aplikacja`.

`zrodla/` — generator logo i skrypt `build.py` (odświeża listę plików pracy offline i numer wersji). Uruchamiany przy kolejnych wersjach — nie jest potrzebny do używania aplikacji.

Dane projektów nie leżą w tym folderze — są w pamięci iPada (lub przeglądarki na laptopie) i w paczkach ZIP z eksportu.
