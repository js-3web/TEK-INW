# TEK-INW — publikacja na GitHub Pages i instalacja na iPadzie

Efekt: aplikacja pod adresem `https://js-3web.github.io/TEK-INW/`, zainstalowana na iPadzie jak zwykła aplikacja (ikona na ekranie początkowym, działa w hali bez internetu).

Dlaczego przez GitHub, a nie z pliku: iPad nie uruchamia aplikacji HTML otwartej z folderu (aplikacja Pliki pokazuje tylko podgląd). Strona z adresem `https://` może się zainstalować i zapisać na urządzeniu.

## 1. Repozytorium (raz)
1. github.com → **New repository** → nazwa **`TEK-INW`** → widoczność **Public** (darmowe GitHub Pages działa z repozytorium publicznym) → **Create repository**.
2. W GitHub Desktop: **File → Clone repository** → `js-3web/TEK-INW` → wybierz folder lokalny (np. `D:\JSarafin\Pryw\TEK-INW\_github\TEK-INW`).

## 2. Wgranie plików (przy każdej wersji)
1. Skopiuj **zawartość** folderu `aplikacja` z tej wersji do lokalnego klonu repozytorium. `index.html` ma leżeć na samej górze repozytorium (nie w podfolderze).
2. GitHub Desktop → opis zmian, np. „TEK-INW 0.1” → **Commit to main** → **Push origin**.
3. **Nie wgrywaj** niczego spoza folderu `aplikacja` (instrukcje, `zrodla`, Twoje projekty i zdjęcia).

## 3. Włączenie strony (raz)
Repozytorium → **Settings → Pages** → Source: **Deploy from a branch**, Branch: **main**, folder **/(root)** → **Save**. Po 1–2 minutach strona będzie pod adresem `https://js-3web.github.io/TEK-INW/`. Czasu publikacji na Twoim koncie nie sprawdzałem.

## 4. Instalacja na iPadzie
1. Otwórz adres w **Safari** (nie w innej przeglądarce).
2. **Udostępnij** (kwadrat ze strzałką) → **Do ekranu początkowego** → **Dodaj**.
3. Uruchom TEK-INW **z ikony** i pracuj tylko tam. Safari i aplikacja z ikony mogą mieć osobne pamięci — projekt założony w Safari może nie być widoczny w aplikacji.
4. Pierwsze uruchomienie z internetem: aplikacja zapisuje swoje pliki (ok. 5 MB). Potem działa bez sieci — sprawdź to raz w trybie samolotowym, zanim pojedziesz na halę.

**Laptop (Edge):** ten sam adres → menu „…” → **Aplikacje → Zainstaluj tę witrynę jako aplikację**. Laptop ma osobną bazę — projekt z iPada przenosisz kopią ZIP (Eksport → Importuj).

## 5. Nowa wersja
1. Wgraj pliki nowej wersji jak w punkcie 2 (zmieniony jest zawsze `js/wersja.js`, `sw.js` i `version.json`).
2. Na iPadzie po otwarciu aplikacji pojawi się komunikat **„Jest nowa wersja TEK-INW — Odśwież”**. Dane zostają.

## Co warto wiedzieć
- **Dane nie trafiają na GitHub.** Na GitHubie jest tylko program. Projekty, podkłady i zdjęcia są w pamięci iPada.
- **Adres i kod są publiczne**, dane — nie. Jeśli kod ma nie być publiczny (produkt komercyjny), potrzebny będzie inny hosting (np. płatny plan GitHub lub Cloudflare Pages z repozytorium prywatnym) — do decyzji przed sprzedażą.
- **Wszystkie strony z konta js-3web dzielą jedną „domenę”** (`js-3web.github.io`). TEK-INW ma własną bazę (`tek-inw`), więc nie miesza się z TEK-BIURO BUDOWY — ale „wyczyść dane witryny” w ustawieniach Safari usunie dane wszystkich tych aplikacji naraz.
- **Kopia po każdym dniu pracy:** zakładka Eksport → zaznacz „Kopia projektu” → Zapisz / Udostępnij → Zachowaj w Plikach.
