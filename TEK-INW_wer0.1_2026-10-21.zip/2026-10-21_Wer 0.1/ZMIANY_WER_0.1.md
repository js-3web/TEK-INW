# TEK-INW — wersja 0.1 (prototyp), 21.10.2026

Pierwsza wersja. Zakres uzgodniony 21.10.2026: (1) zaznaczanie zmian na podkładzie PDF/DXF tak precyzyjnie, żeby dało się je przenieść do DXF, (2) znacznik + zdjęcie → gotowa fotodokumentacja bez ręcznego przypisywania zdjęć.

## Co jest
- Szata i układ TEK-AUDYTOR: lista projektów → projekt z zakładkami; nowe logo TEK-INW (sześciokąt + znacznik miejsca).
- Podkłady **DXF** (współrzędne z pliku, bloki rozwijane, polskie znaki w starszych DXF — ANSI_1250) i **PDF** (wybór stron, kalibracja: 2 punkty o znanych współrzędnych albo znana odległość).
- Plan: przesuwanie i powiększanie palcami, kółkiem myszy i gładzikiem; ostry PDF przy dużym powiększeniu (dorysowanie fragmentu).
- Precyzja: celownik nad palcem + lupa, przyciąganie do narożników / końców / środków / skrzyżowań linii (DXF), Orto, wpis współrzędnych jak w ZWCAD (`x;y`, `@dx;dy`, `@dł<kąt`), edycja współrzędnych w panelu.
- Znaczniki **F** (zdjęcia, kierunek widoku) i **Z**: inny wymiar (rysunek / pomiar / różnica), nowy element, element nie istnieje, uwaga, szkic.
- Zdjęcia z aparatu iPada prosto do znacznika (bez ręcznego przypisywania), kilka zdjęć na punkt, miniatury, podgląd, kolejność.
- Zestawienie znaczników z wyszukiwaniem.
- **Eksport ZIP**: fotodokumentacja PDF (strona tytułowa, spis zdjęć, zestawienie zmian, plany z klikalnymi znacznikami, strona na każde zdjęcie z mini-planem i nawigacją — odnośniki wewnętrzne), zdjęcia JPG, CSV, DXF zmian R12 z warstwami INW-*, `zmiany.json` + prompt dla TEK-RYSOWNIK, kopia projektu.
- Import kopii (ZIP) — przeniesienie projektu iPad → laptop.
- Praca offline (PWA), prośba o trwałą pamięć, cofanie zmian (zdjęcia nie podlegają cofaniu).

## Sprawdzone (Chromium w kontenerze, dane fikcyjne) — skrypty w `testy/`
- Pełny przebieg: projekt przykładowy → 2 punkty F (3 zdjęcia) i 5 zmian Z na DXF i PDF → eksport ZIP → import do czystej przeglądarki: 7 znaczników, 3 zdjęcia, 2 podkłady — komplet.
- Kalibracja PDF dwoma punktami (A/1, D/13): kontrolny punkt C/7 wyszedł 72 000; 48 000 mm — zgodnie z rysunkiem.
- Wymiar z przyciąganiem: linia dokładnie 12 000,000 mm między słupami; pomiar 11,985 m → różnica −15 mm (panel, PDF, CSV, DXF).
- Wpis z klawiatury (`62;6`, `@4;0`, `@0;36`, `@-4;0`) — obrys „brak” w dokładnych współrzędnych.
- Dotyk (emulacja ekranu dotykowego): szczypanie ×2,0, przesuwanie palcem, celownik nad palcem + lupa, przyciąganie.
- PDF fotodokumentacji: 8 stron, 32 odnośniki wewnętrzne, 0 błędnych; polskie znaki w tekście; podkład PDF wstawiony jako wektor.
- DXF zmian: format R12, odczyt i audyt biblioteką ezdxf bez błędów, 7 warstw INW-*, współrzędne zgodne z rysunkiem.
- DXF: UTF-8 (AC1032) i CP1250 (AC1015) — polskie znaki poprawne; duży plik 11 MB / 140 tys. linii odczytany w 1,2 s (w kontenerze; iPad będzie wolniejszy).
- Przykładowy wynik: `testy/PRZYKLAD_fotodokumentacja.pdf` i `testy/PRZYKLAD_paczka_eksportu.zip`.

## Niesprawdzone — do testu na iPadzie
- Safari na iPadzie (WebKit) — w kontenerze dostępny był tylko Chromium.
- Aparat w trybie aplikacji z ekranu początkowego, okno „Udostępnij” dla dużego ZIP, trwałość pamięci po kilku dniach.
- Wydajność na prawdziwym, dużym DXF hali i na ciężkim PDF A0.
- Otwarcie `zmiany_*.dxf` w ZWCAD 2022 (format R12 sprawdzony biblioteką ezdxf).

## Ograniczenia
- Przyciąganie tylko na DXF; kreskowania i atrybuty bloków nie są wyświetlane.
- Jeden projekt = jedno urządzenie (przenoszenie kopią ZIP).
- Brak modułu opisu technicznego i kontroli pomiarów (odchyłka zamknięcia, przeliczenie lico → oś) — planowane.
