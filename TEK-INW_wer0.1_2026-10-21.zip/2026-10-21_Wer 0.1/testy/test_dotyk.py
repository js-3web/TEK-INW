"""Test obsługi dotyku (jak na iPadzie): celownik przesunięty nad palec, przyciąganie, szczypanie, przesuwanie jednym palcem."""
import time, pathlib
from playwright.sync_api import sync_playwright
OUT = pathlib.Path(__file__).parent / 'wyniki'
with sync_playwright() as p:
    b = p.chromium.launch(args=['--disable-gpu'])
    ctx = b.new_context(viewport={'width': 1080, 'height': 810}, has_touch=True, is_mobile=False, device_scale_factor=2)
    page = ctx.new_page(); bledy = []; page.on('pageerror', lambda e: bledy.append(str(e)))
    page.goto('http://localhost:8765/'); page.wait_for_selector('.hero')
    page.tap('[data-act=demo] >> nth=0'); page.wait_for_selector('#planHost'); time.sleep(2)
    cdp = ctx.new_cdp_session(page)
    def dotyk(typ, pkt): cdp.send('Input.dispatchTouchEvent', {'type': typ, 'touchPoints': [{'x': x, 'y': y, 'id': i} for i, (x, y) in enumerate(pkt)]})
    def ekr(sx, sy):
        v = page.evaluate('Plan.widok()'); bx = page.locator('#planHost').bounding_box(); return bx['x'] + sx * v['s'] + v['tx'], bx['y'] + sy * v['s'] + v['ty']
    ark = lambda X, Y: page.evaluate(f'Geom.zastosuj(Plan.arkusz().Ti, {X}, {Y})')
    # 1. szczypanie (powiększenie ×2 wokół środka)
    v0 = page.evaluate('Plan.widok()'); bx = page.locator('#planHost').bounding_box(); cx, cy = bx['x'] + bx['width'] / 2, bx['y'] + bx['height'] / 2
    dotyk('touchStart', [(cx - 50, cy), (cx + 50, cy)])
    for k in range(1, 11): dotyk('touchMove', [(cx - 50 - 5 * k, cy), (cx + 50 + 5 * k, cy)]); time.sleep(0.02)
    dotyk('touchEnd', []); time.sleep(0.6)
    v1 = page.evaluate('Plan.widok()'); print('szczypanie: powiększenie', round(v1['s'] / v0['s'], 2), '(oczekiwane 2,0)')
    # 2. jeden palec w narzędziu „Przeglądaj” przesuwa
    dotyk('touchStart', [(cx, cy)]); [dotyk('touchMove', [(cx + 8 * k, cy + 4 * k)]) for k in range(1, 11)]; dotyk('touchEnd', []); time.sleep(0.4)
    v2 = page.evaluate('Plan.widok()'); print('przesunięcie palcem:', round(v2['tx'] - v1['tx']), round(v2['ty'] - v1['ty']), '(oczekiwane 80 40)')
    # 3. wymiar palcem: palec 78 px PONIŻEJ punktu, celownik trafia w słup A/5 i A/6 (przyciąganie)
    page.evaluate('Plan.dopasuj()'); time.sleep(0.5); page.tap('[data-narz=wymiar]')
    for X in (48000, 60000):
        x, y = ekr(*ark(X + 200, 24150)); dotyk('touchStart', [(x, y + 78)]); dotyk('touchMove', [(x + 1, y + 79)]); time.sleep(0.1)
        if X == 48000: page.screenshot(path=str(OUT / '10_lupa.png'))
        dotyk('touchEnd', []); time.sleep(0.2)
    z = page.evaluate("S.znaczniki.filter(z => z.typZ === 'wymiar').map(z => z.geom.pkt.map(p => Geom.zastosuj(Plan.arkusz().T, ...p).map(Math.round)))")
    print('wymiar palcem (świat, mm):', z, '(oczekiwane [[48000,24000],[60000,24000]])')
    page.screenshot(path=str(OUT / '11_po_dotyku.png'))
    print('błędy:', bledy or 'brak'); b.close()
