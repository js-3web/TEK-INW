"""Test end-to-end TEK-INW w Chromium (Playwright): projekt przykładowy → znaczniki F i Z → kalibracja PDF → eksport ZIP → import."""
import sys, time, json, pathlib
from playwright.sync_api import sync_playwright

T = pathlib.Path(__file__).parent
URL = 'http://localhost:8765/'
OUT = T / 'wyniki'; OUT.mkdir(exist_ok=True)
bledy = []

def ekran(page, n): page.screenshot(path=str(OUT / f'{n}.png'))

def na_ekran(page, sx, sy):
    v = page.evaluate('Plan.widok()'); box = page.locator('#planHost').bounding_box()
    return box['x'] + sx * v['s'] + v['tx'], box['y'] + sy * v['s'] + v['ty']

def klik_arkusz(page, sx, sy):
    x, y = na_ekran(page, sx, sy); page.mouse.move(x, y); page.mouse.down(); page.mouse.up(); time.sleep(0.15)

def swiat_na_ark(page, X, Y):
    return page.evaluate(f'(() => {{ const r = Plan.arkusz(); return Geom.zastosuj(r.Ti, {X}, {Y}); }})()')

with sync_playwright() as p:
    b = p.chromium.launch(args=['--disable-gpu'])
    ctx = b.new_context(viewport={'width': 1366, 'height': 900}, accept_downloads=True)
    page = ctx.new_page()
    page.on('console', lambda m: bledy.append(f'console.{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
    page.on('pageerror', lambda e: bledy.append(f'pageerror: {e}'))
    page.goto(URL); page.wait_for_selector('.hero'); time.sleep(0.5); ekran(page, '01_start')
    # projekt przykładowy
    page.click('[data-act=demo] >> nth=0'); page.wait_for_selector('#planHost'); time.sleep(2.0); ekran(page, '02_plan_dxf')
    # F: punkt + kierunek (przeciągnięcie) + zdjęcie z aparatu (wybór pliku)
    page.click('[data-narz=foto]')
    p1 = swiat_na_ark(page, 30000, 12000)
    x, y = na_ekran(page, *p1)
    with page.expect_file_chooser() as fc:
        page.mouse.move(x, y); page.mouse.down(); page.mouse.move(x + 40, y - 30, steps=5); page.mouse.up()
    fc.value.set_files(str(T / 'foto1.jpg')); time.sleep(2.0)
    # drugie zdjęcie do tego samego punktu — z galerii
    with page.expect_file_chooser() as fc:
        page.click('[data-act=zdj-galeria]')
    fc.value.set_files([str(T / 'foto2.jpg')]); time.sleep(2.0)
    page.fill('[data-zm=element]', 'SŁ-B/3'); page.fill('[data-zm=opis]', 'Słup prefabrykowany, widoczne odpryski otuliny w strefie przypodłogowej.')
    ekran(page, '03_foto')
    # Z wymiar: dwa punkty z przyciąganiem (słupy A/2 i A/3 → 12 m)
    page.click('[data-narz=wymiar]')
    for X, Y in [(12000, 0), (24000, 0)]:
        q = swiat_na_ark(page, X + 150, Y + 120); klik_arkusz(page, *q)
    time.sleep(0.3); page.fill('#zPom', '11,985'); page.dispatch_event('#zPom', 'input'); time.sleep(0.3)
    page.fill('[data-zm=element]', 'rozstaw osi 2–3'); ekran(page, '04_wymiar')
    # Z nowy: prostokąt
    page.click('[data-narz=nowy]'); page.click('label:has([data-podtryb=prost])')
    for X, Y in [(40000, 50000), (46000, 54000)]:
        q = swiat_na_ark(page, X, Y); klik_arkusz(page, *q)
    # Z brak: polilinia z klawiatury
    page.click('[data-narz=brak]'); page.click('label:has([data-podtryb=polilinia])')
    for t in ['62;6', '@4;0', '@0;36', '@-4;0']:
        page.fill('#wpisPole', t); page.press('#wpisPole', 'Enter'); time.sleep(0.1)
    page.click('[data-act=pl-zamknij]'); time.sleep(0.2)
    page.fill('[data-zm=opis]', 'Regał z rysunku nie istnieje — miejsce wolne.')
    # Z uwaga
    page.click('[data-narz=uwaga]'); q = swiat_na_ark(page, 100000, 30000); klik_arkusz(page, *q)
    page.fill('[data-zm=opis]', 'Ślady przecieku na posadzce pod świetlikiem.')
    # szkic
    page.click('[data-narz=szkic]'); a = na_ekran(page, *swiat_na_ark(page, 80000, 60000)); page.mouse.move(*a); page.mouse.down()
    for k in range(12): page.mouse.move(a[0] + k * 6, a[1] + (k % 3) * 5)
    page.mouse.up(); time.sleep(0.3)
    page.click('[data-narz=przegladaj]'); page.click('[data-act=plan-dopasuj]'); time.sleep(0.8); ekran(page, '05_zmiany_dxf')
    # arkusz PDF: kalibracja
    pdf_id = page.evaluate("S.arkusze.find(a => a.typ === 'pdf').id")
    page.select_option('#arkSel', pdf_id); time.sleep(3.0)
    page.click('[data-act=ark-kalibruj-plan]'); time.sleep(0.3)
    s = 0.013714285714285714; ox = 40 + 16000 * s; oy = 1684 - 40 - 20000 * s
    for X, Y in [(0, 0), (144000, 72000)]:
        klik_arkusz(page, ox + X * s, oy - Y * s)
    page.wait_for_selector('#kalForm'); page.fill('[name=x1]', '0'); page.fill('[name=y1]', '0'); page.fill('[name=x2]', '144'); page.fill('[name=y2]', '72')
    page.click('#kalForm button[type=submit]'); time.sleep(0.5)
    T_pdf = page.evaluate("S.arkusze.find(a => a.typ === 'pdf').kal.T")
    # kontrola kalibracji: punkt osi C/7 (72 m, 48 m)
    sx, sy = ox + 72000 * s, oy - 48000 * s
    w = page.evaluate(f"Geom.zastosuj(S.arkusze.find(a => a.typ === 'pdf').kal.T, {sx}, {sy})")
    print('kontrola kalibracji C/7 [mm]:', [round(v, 1) for v in w])
    # F na PDF
    page.click('[data-narz=foto]'); x, y = na_ekran(page, ox + 120000 * s, oy - 20000 * s)
    with page.expect_file_chooser() as fc:
        page.mouse.move(x, y); page.mouse.down(); page.mouse.move(x - 40, y + 10, steps=4); page.mouse.up()
    fc.value.set_files(str(T / 'foto3.jpg')); time.sleep(2.0)
    page.fill('[data-zm=element]', 'dok D-11'); ekran(page, '06_plan_pdf')
    # zestawienie
    page.click('[data-tab=lista]'); time.sleep(0.5); ekran(page, '07_lista')
    # eksport
    page.click('[data-tab=eksport]'); time.sleep(0.5)
    page.click('[data-act=eksport-start]')
    try:
        page.wait_for_selector('[data-act=eksport-pobierz], .toast.zly.show', timeout=150000)
        if not page.query_selector('[data-act=eksport-pobierz]'): raise RuntimeError('eksport: błąd')
    except Exception as e:
        ekran(page, '08_blad'); print('POSTĘP:', page.inner_text('#ekspPostep')); print('TOAST:', page.inner_text('#toast')); print('\n'.join(bledy)); raise
    ekran(page, '08_eksport')
    with page.expect_download() as dl:
        page.click('[data-act=eksport-pobierz]')
    zipp = OUT / dl.value.suggested_filename; dl.value.save_as(str(zipp)); print('ZIP:', zipp.name, zipp.stat().st_size)
    stan = page.evaluate('JSON.stringify(S)'); (OUT / 'stan_projektu.json').write_text(stan, encoding='utf-8')
    # import w nowym kontekście (czysta baza)
    ctx2 = b.new_context(viewport={'width': 1366, 'height': 900}); p2 = ctx2.new_page(); p2.on('pageerror', lambda e: bledy.append(f'pageerror(import): {e}'))
    p2.goto(URL); p2.wait_for_selector('.hero')
    with p2.expect_file_chooser() as fc:
        p2.click('[data-act=import]')
    fc.value.set_files(str(zipp)); p2.wait_for_selector('#planHost', timeout=60000); time.sleep(2.5); ekran(p2, '09_po_imporcie')
    n = p2.evaluate('[S.znaczniki.length, S.znaczniki.reduce((s,z)=>s+z.zdjecia.length,0), S.arkusze.length]'); print('po imporcie [znaczniki, zdjęcia, arkusze]:', n)
    b.close()
print('\n'.join(bledy) or 'brak błędów w konsoli')
