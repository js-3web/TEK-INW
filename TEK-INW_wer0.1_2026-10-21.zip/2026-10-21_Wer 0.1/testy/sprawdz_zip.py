"""Kontrola paczki ZIP z TEK-INW: zawartość, PDF (strony, odnośniki), DXF (odczyt ezdxf + audyt), CSV, JSON."""
import sys, zipfile, io, json, pathlib
import pypdf, ezdxf, pymupdf

z = zipfile.ZipFile(sys.argv[1]); out = pathlib.Path(sys.argv[2]); out.mkdir(exist_ok=True)
naz = z.namelist(); print(len(naz), 'plików:'); [print('  ', n, z.getinfo(n).file_size) for n in naz]
pdfn = [n for n in naz if n.endswith('_fotodokumentacja.pdf')][0]
data = z.read(pdfn); r = pypdf.PdfReader(io.BytesIO(data))
print('\nPDF:', pdfn, len(data), 'B, stron', len(r.pages), '| tytuł:', r.metadata.title)
refs = {p.indirect_reference.idnum: i + 1 for i, p in enumerate(r.pages)}
zle = 0; ile = 0
for i, p in enumerate(r.pages):
    for a in p.get('/Annots') or []:
        a = a.get_object()
        if a.get('/Subtype') != '/Link': continue
        ile += 1; d = a.get('/Dest')
        cel = d[0].idnum if d else None
        if cel not in refs: zle += 1
print(f'odnośniki wewnętrzne: {ile}, błędne cele: {zle}')
txt = r.pages[0].extract_text(); print('tekst str.1 (fragment):', txt[:160].replace('\n', ' | '))
doc = pymupdf.open(stream=data, filetype='pdf')
for i in range(len(doc)):
    pix = doc[i].get_pixmap(dpi=60 if doc[i].rect.width < 1000 else 22); pix.save(str(out / f'pdf_str{i + 1:02d}.png'))
for n in [n for n in naz if n.endswith('.dxf') and not n.startswith('_kopia')]:
    tmp = out / pathlib.Path(n).name; tmp.write_bytes(z.read(n)); d = ezdxf.readfile(tmp); aud = d.audit()
    msp = d.modelspace(); typy = {}
    for e in msp: typy[e.dxftype()] = typy.get(e.dxftype(), 0) + 1
    teksty = [e.dxf.text for e in msp.query('TEXT')][:6]
    print(f'\nDXF {n}: wersja {d.dxfversion}, warstwy {[l.dxf.name for l in d.layers]}, encje {typy}, błędy audytu {len(aud.errors)}')
    print('  teksty:', teksty)
    for e in msp.query('LINE[layer=="INW-WYMIAR"]')[:1]: print('  linia wymiaru:', tuple(round(v) for v in e.dxf.start)[:2], tuple(round(v) for v in e.dxf.end)[:2])
for n in [n for n in naz if n.endswith('.csv')]:
    t = z.read(n).decode('utf-8-sig').splitlines(); print(f'\n{n}: {len(t) - 1} wierszy; nagłówek: {t[0][:120]}'); print('  ', t[1][:160] if len(t) > 1 else '')
j = json.loads(z.read('zmiany.json')); print('\nzmiany.json:', len(j['zmiany']), 'zmian; pierwsza:', json.dumps(j['zmiany'][0], ensure_ascii=False)[:300])
