# TEK-INW 0.1 — instrukcja pracy (iPad 9 + dalmierz)

## Przed wyjazdem (laptop, ZWCAD 2022)
1. **Kopia rysunku → czysty podkład.** Usuń kreskowania (HATCH), obrazy, odnośniki zewnętrzne. Zamroź zbędne warstwy. Zostaw osie, słupy, ściany, bramy, doki, regały.
2. **`ZAPISZJAKO` → DXF** (tekstowy, np. AutoCAD 2018 DXF). Binarnego DXF aplikacja nie czyta.
3. Opcjonalnie **PDF** — np. gdy klient dał tylko PDF. PDF trzeba skalibrować (patrz niżej).
4. Prześlij pliki na iPada (OneDrive / iCloud Drive) → TEK-INW → **2. Podkłady → Dodaj podkład**.
5. **Test w trybie samolotowym**: otwórz aplikację z ikony bez internetu. Jeśli działa — możesz jechać.

## Na obiekcie
| Narzędzie | Co robi | Jak |
|---|---|---|
| **Przeglądaj** | przesuwanie, wybór znacznika | jeden palec przesuwa, dwa powiększają; stuknięcie w znacznik otwiera panel |
| **Foto (F)** | punkt zdjęcia | stuknij miejsce → otwiera się aparat. **Przeciągnij** od miejsca w stronę, w którą patrzysz — zapisze się kierunek (stożek na planie). Kolejne zdjęcia tego miejsca: panel → „Zrób zdjęcie” |
| **Wymiar** | inny wymiar / położenie | dwa punkty elementu → w panelu wpisz **wynik z dalmierza**. Aplikacja pokazuje wymiar z rysunku i różnicę |
| **Nowy** | element, którego nie ma na rysunku | linia / prostokąt / polilinia; punkty wskazujesz palcem albo wpisujesz z klawiatury |
| **Brak** | element z rysunku nie istnieje | obrysuj go (prostokąt lub polilinia) |
| **Uwaga** | uwaga w punkcie | stuknij, opis w panelu (mikrofon na klawiaturze = dyktowanie) |
| **Szkic** | rysunek odręczny | do interpretacji w biurze — to nie jest pomiar |
| **Pomiar** | długość na rysunku | nic się nie zapisuje |

**Precyzja palcem:** po dotknięciu nad palcem pojawia się **celownik i lupa**. Przesuń palec, aż celownik trafi w punkt (na DXF zielony kwadrat = przyciągnięcie do narożnika / końca / skrzyżowania osi). Punkt zapisuje się po **oderwaniu** palca.

**Precyzja liczbą** (podkład DXF albo skalibrowany PDF): pole na dole planu przyjmuje zapis jak w ZWCAD, w metrach (albo mm — ustawienie projektu):
- `12;6` — punkt o współrzędnych X=12, Y=6,
- `@4;0` — 4 m w prawo od poprzedniego punktu,
- `@5,985<90` — 5,985 m pod kątem 90° (w górę) od poprzedniego punktu.
Separator współrzędnych to **średnik**, część dziesiętna — przecinek lub kropka.

**Rysik (Apple Pencil):** po pierwszym użyciu aplikacja przełącza się sama — rysik stawia punkty, palec tylko przesuwa i powiększa.

**Element (oznaczenie):** wpisuj tak, jak będzie w opisie i na rysunku (np. `SŁ-C/4`, `B-07`). Ten sam numer łączy zdjęcie, rysunek i opis.

## Kalibracja PDF
1. Zakładka Plan → **Kalibruj**.
2. Wskaż dwa punkty jak najdalej od siebie, najlepiej skrzyżowania osi (np. A/1 i D/13). Powiększ mocno przed wskazaniem — błąd wskazania przenosi się na wszystkie wymiary.
3. Wpisz ich współrzędne z ZWCAD (albo tylko odległość między nimi).
4. **Sprawdź**: narzędzie **Pomiar** na znanym wymiarze (rozstaw osi). Różnica większa niż kilka cm = powtórz kalibrację.

## Po wizji
1. **Eksport → Przygotuj paczkę → Zapisz / Udostępnij → Zachowaj w Plikach** (OneDrive / iCloud Drive).
2. Na laptopie rozpakuj ZIP:
   - `*_fotodokumentacja.pdf` — gotowa fotodokumentacja z klikalnymi punktami,
   - `zdjecia\` — zdjęcia z nazwami `F-012_1.jpg`,
   - `zmiany_<plan>.dxf` — w ZWCAD: **Wstaw → Odnośnik zewnętrzny (XREF)** w punkcie 0,0, skala 1 → nakłada się na oryginał,
   - `zmiany.json` + `PROMPT_naniesienie_zmian.txt` — dla Claude (TEK-RYSOWNIK),
   - `zestawienie_*.csv` — tabele do Excela.
3. **Kopia projektu** jest w tej samej paczce — na laptopie (Edge, ten sam adres) **Importuj kopię** i możesz dalej pracować na dużym ekranie.

## Ważne
- Dane są **tylko na iPadzie**, dopóki nie zrobisz eksportu. Rób kopię po każdym dniu.
- Zdjęcia osób i tablic rejestracyjnych to dane osobowe — fotografuj za zgodą zarządcy, unikaj ludzi w kadrze.
- To wersja próbna (0.1). Sprawdź ją na projekcie przykładowym i na jednym prawdziwym rzucie, zanim oprzesz na niej termin inwentaryzacji.
