#!/usr/bin/env python3
"""Generator logo TEK-INW w systemie identyfikacji TEKTORIA — ten sam układ co logo TEK-AUDYTOR
(sześciokąt marki, Space Grotesk Bold zamieniony na krzywe, ta sama paleta i wysokość wersalików).
Znak produktu: sześciokąt + znacznik miejsca („pinezka” na rzucie) — inwentaryzacja = punkt na planie + zdjęcie.
Wynik: logo/out/*.svg, ikony PNG aplikacji (icons/) oraz js/logo.js w folderze aplikacji.
Użycie: python gen_logo.py "<folder aplikacji>" """
import json, math, pathlib, re, sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

HERE = pathlib.Path(__file__).parent
APP = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent.parent / 'aplikacja'
FONT = TTFont(str(HERE / 'package/700Bold/SpaceGrotesk_700Bold.ttf'))
GS = FONT.getGlyphSet(); CMAP = FONT.getBestCmap(); UPM = FONT['head'].unitsPerEm; CAP = FONT['OS/2'].sCapHeight

NAVY, CYAN, WHITE, INK, CYAN_DARK = '#0B1622', '#22C3E6', '#F2F6F9', '#0B1622', '#0A8FB0'
H, SW = 128, 9.0
CAP_PX = 120 * 0.42
TRACK = 0.06


def r(x): return f'{x:.2f}'.rstrip('0').rstrip('.')


def text_paths(text, size, tracking=TRACK):
    s = size / UPM; x = 0; out = []
    for i, ch in enumerate(text):
        g = CMAP[ord(ch)]; pen = SVGPathPen(GS, ntos=lambda v: r(v))
        GS[g].draw(TransformPen(pen, (s, 0, 0, -s, x, 0)))
        out.append(pen.getCommands()); x += GS[g].width * s
        if i < len(text) - 1: x += tracking * size
    return out, x


def hex_v(cx, cy, R):
    a = R * math.sqrt(3) / 2
    pts = [(cx, cy - R), (cx + a, cy - R / 2), (cx + a, cy + R / 2), (cx, cy + R), (cx - a, cy + R / 2), (cx - a, cy - R / 2)]
    return 'M' + ' L'.join(f'{r(x)},{r(y)}' for x, y in pts) + ' Z'


def ikona(cx, cy, R, col, sw, fill='none'):
    """Znak produktu: sześciokąt marki + znacznik miejsca (pinezka z punktem)."""
    k = R / 55.5
    rp = 15.5 * k                       # promień główki pinezki
    py = cy - 9 * k                     # środek główki
    a = math.radians(38)                # miejsce przejścia łuku w ostrze
    x1, y1 = cx - rp * math.cos(a), py + rp * math.sin(a)
    x2, y2 = cx + rp * math.cos(a), py + rp * math.sin(a)
    tip = cy + 26 * k
    pin = f'M{r(x1)},{r(y1)} A{r(rp)},{r(rp)} 0 1 1 {r(x2)},{r(y2)} L{r(cx)},{r(tip)} Z'
    return (f'<path d="{hex_v(cx, cy, R - sw / 2)}" fill="{fill}" stroke="{col}" stroke-width="{r(sw)}" stroke-linejoin="miter"/>'
            f'<path d="{pin}" fill="none" stroke="{col}" stroke-width="{r(sw * 1.0)}" stroke-linejoin="miter"/>'
            f'<circle cx="{r(cx)}" cy="{r(py)}" r="{r(5.2 * k)}" fill="{col}"/>')


def svg(w, h, body, extra=''):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {r(w)} {r(h)}"{extra}>{body}</svg>'


def produkt(col_hex, col_a, col_b):
    size = CAP_PX / (CAP / UPM)
    a_txt, b_txt = 'TEK', '-INW'
    paths, tw = text_paths(a_txt + b_txt, size)
    R = (H - 8) / 2 + SW * 0.1
    a = R * math.sqrt(3) / 2
    P = 4; cx = P + a; cy = H / 2; x0 = cx + a + 26
    g = ''.join(f'<path d="{d}" fill="{col_a if i < len(a_txt) else col_b}"/>' for i, d in enumerate(paths))
    body = ikona(cx, cy, R, col_hex, SW) + f'<g transform="translate({r(x0)},{r(cy + CAP_PX / 2)})">{g}</g>'
    return svg(x0 + tw + P, H, body, ' role="img" aria-label="TEK-INW"')


def favicon(bg=NAVY, pad=0):
    s = 64
    body = (f'<rect width="{s}" height="{s}" fill="{bg}"/>' if pad else '') + ikona(32, 32, 29 - pad, CYAN, 5, NAVY)
    return svg(s, s, body)


def tektoria(ciemne=True):
    src = (HERE / 'tektoria-logo-poziome_ciemne-tlo.svg').read_text(encoding='utf-8')
    s = re.sub(r'<metadata>.*?</metadata>', '', src, flags=re.S)
    s = re.sub(r'\s+xmlns:c2pa="[^"]*"', '', s)
    s = re.sub(r'\s(width|height)="\d+"', '', s, count=2)
    s = re.sub(r'(\d+\.\d{3})\d+', r'\1', s)
    s = s.replace('<svg ', '<svg role="img" aria-label="TEKTORIA" ', 1)
    assert s.count('<path') == 9, 'nieoczekiwana budowa logo TEKTORIA'
    if not ciemne: s = s.replace('#F2F6F9', INK).replace('#22C3E6', CYAN_DARK)
    return s


out = HERE / 'out'; out.mkdir(exist_ok=True)
L = {
    'produktCiemne': produkt(CYAN, WHITE, CYAN),
    'produktJasne': produkt(CYAN_DARK, INK, CYAN_DARK),
    'tektoriaCiemne': tektoria(True),
    'tektoriaJasne': tektoria(False),
    'ikona': favicon(),
}
for k, n in {'produktCiemne': 'tek-inw-logo_ciemne-tlo', 'produktJasne': 'tek-inw-logo_jasne-tlo', 'ikona': 'tek-inw-ikona'}.items():
    (out / f'{n}.svg').write_text(L[k], encoding='utf-8')
js = '/* TEK-INW — logo aplikacji i logo marki TEKTORIA (plik generowany przez zrodla/logo/gen_logo.py — nie edytować ręcznie). */\nconst LOGO = ' + json.dumps(L, ensure_ascii=False, indent=1) + ';\n'
(APP / 'js' / 'logo.js').write_text(js, encoding='utf-8')
(APP / 'icons').mkdir(exist_ok=True)
(APP / 'icons' / 'favicon.svg').write_text(L['ikona'], encoding='utf-8')
try:
    import cairosvg
    kafel = svg(64, 64, f'<rect width="64" height="64" fill="{NAVY}"/>' + ikona(32, 32, 22, CYAN, 3.6, NAVY))  # ikona ekranu początkowego: pełne tło, margines bezpieczny
    for px in (180, 192, 512):
        cairosvg.svg2png(bytestring=kafel.encode(), write_to=str(APP / 'icons' / f'icon-{px}.png'), output_width=px, output_height=px)
    cairosvg.svg2png(bytestring=L['produktCiemne'].encode(), write_to=str(out / 'tek-inw-logo_podglad.png'), output_width=900,
                     background_color=NAVY)
except ImportError:
    print('Brak cairosvg — ikony PNG nie zostały odświeżone.')
print({k: len(v) for k, v in L.items()})
