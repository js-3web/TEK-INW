#!/usr/bin/env python3
"""TEK-INW — przygotowanie folderu „aplikacja” do publikacji.
Co robi:
 1. generuje logo i ikony (zrodla/logo/gen_logo.py),
 2. tworzy sw.js — „service worker”, czyli mały program, który zapisuje pliki aplikacji na urządzeniu,
    dzięki czemu TEK-INW działa w hali bez internetu; lista plików i numer wersji są wpisywane automatycznie,
 3. tworzy version.json z numerem wersji (z js/wersja.js).
Użycie:  python build.py "..\\2026-10-21_Wer 0.1\\aplikacja" """
import json, pathlib, re, subprocess, sys

HERE = pathlib.Path(__file__).parent
APP = pathlib.Path(sys.argv[1]).resolve()
subprocess.run([sys.executable, str(HERE / 'logo' / 'gen_logo.py'), str(APP)], check=True)
w = (APP / 'js' / 'wersja.js').read_text(encoding='utf-8')
cache = re.search(r"cache: '([^']+)'", w).group(1)
nr = re.search(r"nr: '([^']+)'", w).group(1)
pomin = {'sw.js', 'version.json'}
pliki = sorted(str(p.relative_to(APP)).replace('\\', '/') for p in APP.rglob('*') if p.is_file() and p.name not in pomin and 'licencje' not in p.parts)
sw = f"""/* TEK-INW — service worker (plik generowany przez zrodla/build.py — nie edytować ręcznie).
   Zapisuje pliki aplikacji w pamięci urządzenia przy pierwszym uruchomieniu; potem aplikacja działa bez internetu.
   Nowa wersja = nowa nazwa pamięci ({cache}); stara jest usuwana po aktywacji. */
const CACHE = '{cache}';
const PLIKI = {json.dumps(['./'] + pliki, ensure_ascii=False, indent=0)};
self.addEventListener('install', (e) => {{ e.waitUntil(caches.open(CACHE).then(c => c.addAll(PLIKI))); }});
self.addEventListener('activate', (e) => {{ e.waitUntil(caches.keys().then(k => Promise.all(k.filter(n => n.startsWith('tek-inw-') && n !== CACHE).map(n => caches.delete(n)))).then(() => self.clients.claim())); }});
self.addEventListener('message', (e) => {{ if (e.data && e.data.typ === 'aktywuj') self.skipWaiting(); }});
self.addEventListener('fetch', (e) => {{
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  if (u.pathname.endsWith('/version.json')) return; // zawsze z sieci
  e.respondWith(caches.match(e.request, {{ ignoreSearch: true }}).then(r => r || fetch(e.request).catch(() => e.request.mode === 'navigate' ? caches.match('./') : Response.error())));
}});
"""
(APP / 'sw.js').write_text(sw, encoding='utf-8')
(APP / 'version.json').write_text(json.dumps({'wersja': nr, 'cache': cache}), encoding='utf-8')
rozm = sum(p.stat().st_size for p in APP.rglob('*') if p.is_file())
print(f'sw.js: {len(pliki)} plików, cache {cache}; razem {rozm / 1048576:.1f} MB')
